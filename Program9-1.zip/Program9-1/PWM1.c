
unsigned ch1,ch2;

void PORT_Init() {
     PORTE=0x00; // clear porta
     TRISE=0x03; // RA0:RA1 are input
     ANSEL|=0x60; // select AN5:AN6
     OSCCON|=0x70;  // select INTRC
     }

void System_Init() {
     ADC_Init();   // Initalize ADC with default
     PWM1_Init(5000);  // Initalize CCP1 with 5kHz
     PWM2_Init(5000);  // Initalize CCP2 with 5kHz
     PWM1_Start();     // start PWM1 with 0%
     PWM2_Start();     // start PWM2 with 0%
     }

void analog_speed() {
     ch1=ADC_Get_Sample(5);     // read POT at AN0
     ch1=255.0*ch1/1024;        // scale it to 0:255
     delay_ms(10);
     ch2=ADC_Get_Sample(6);     // read POT at AN1
     ch2=255.0*ch2/1024;       // scale it to 0:255
     delay_ms(10);
     PWM1_Set_Duty(ch1);       // signal output
     PWM2_Set_Duty(ch2);
     }
     
void main() {

     PORT_Init();
     System_Init();
     while(1)
     analog_speed();
}