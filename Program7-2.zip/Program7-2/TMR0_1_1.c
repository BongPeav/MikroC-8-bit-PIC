
#define OUTPUT PORTD.RD0

void main() {
     PORTD=0x00;                // CLEAR PORTD
     TRISD=0x00;                 // SET PORTD AS OUTPUT
     OSCCON|=0x70;                 // SELECT INTERNAL OSCILLATOR 8MHz
     OPTION_REG.T0CS=0;           // SELCT INTERNAL SOURCE
     OPTION_REG.PSA=1;       // Prescaler Assigned to WDT
     OPTION_REG&=0xF8 ;      // SELECT 1:1 Prescaler
     TMR0=0;                // CLEAR TIMER0
     while(1) 
     if(INTCON.T0IF){
        INTCON.T0IF=0;
        PORTD^=1;
     }
}