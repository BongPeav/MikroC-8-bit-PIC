

sbit LCD_RS at RB4_bit;
sbit LCD_EN at RB5_bit;
sbit LCD_D4 at RB0_bit;
sbit LCD_D5 at RB1_bit;
sbit LCD_D6 at RB2_bit;
sbit LCD_D7 at RB3_bit;
sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;

#define TRIG PORTD.RD0      // Trigger Pin is connected to RD0
#define ECHO PORTD.RD1      // ECHO Pin is connected to RD1

void main()
{
     unsigned long Tm;
     char Tl, Th;
     unsigned distance;
     char Txt[7];
     PORTD=0x00;
     TRISD=0x02;
     ANSELH = 0;
     OSCCON|=0x70;
     Lcd_Init();
     Lcd_Cmd(_LCD_CURSOR_OFF);
     Lcd_Out(1,1,"Starting Up.");
     Delay_Ms(2000);
     T1CON=0x10;           // select 1:2 Prescaler and Ignore others
     while(1)
     {
            TMR1H = 0;
            TMR1L = 0;
            // initialize the communication
            TRIG = 0;
            Delay_us(5);
            TRIG = 1;
            Delay_us(10);
            TRIG = 0;
            // wait for echo back
            while(ECHO == 0);
            T1CON.TMR1ON=1;
            while(ECHO == 1);
            T1CON.TMR1ON = 0;    // sampling
            // end of transmission
            Tl = TMR1L;
            Th = TMR1H;
            Tm = Th*256 + Tl;   // making 16-bit value
            Distance=Tm/58;
            IntToStr(Distance, Txt);
            Lcd_Cmd(_LCD_CLEAR);
            Lcd_Out(1,1, "Distance (cm)");
            Lcd_Out(2,1, Txt);
            Delay_Ms(1000);
     }
}