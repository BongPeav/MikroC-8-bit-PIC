#define Ticks_Per_Ms 4
#define OUTPUT PORTD.RD0

char counter;
unsigned ms_count;
void interrupt() {
     if(INTCON.T0IF) {
        counter++;
        if(counter==Ticks_Per_Ms)
           { counter=0; ms_count++;}
           }
     INTCON.T0IF=0;     // CLEAR INTERRUPT FLAG
}

void ms_delay(unsigned count) {
     while(ms_count<count);
      ms_count=0;
     }
     
void main() {
     PORTD=0x00;        // CLEAR PORTD
     TRISD=0x00;        // SET PORTD OUTPUT
     OSCCON|=0x70;      // SELECT 8MHz INTRC
     OPTION_REG.T0CS=0; // SELECT INTERNAL SOURCE
     OPTION_REG.PSA=0;  // PRESCALER ASSIGNED TO TIMER0
     OPTION_REG&=0xF8;  // SELECT 1:2 PRESCALER
     INTCON.GIE=1;      // ENABLE GLOBAL INTERRUPT
     INTCON.T0IE=1;     // ENABLE TIMER0 OVERFLOW INTERRUPT
     INTCON.T0IF=0;     // CLEAR INTERRUPT FLAG
     counter=0;
     ms_count=0;
     TMR0=0;            // CLEAR TIMER0
     while(1) {
              OUTPUT=1;
              ms_delay(100);
              OUTPUT=0;
              ms_delay(50);
              }
}