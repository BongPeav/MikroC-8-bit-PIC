
void PORT_Init() {
     PORTA=0x00;        // Clear PORTA
     PORTC=0x00;        // Clear PORTC
     PORTD=0x00;        // Clear PORTD
     TRISA=0x01;        // RA0 AS ANALOG INPUT
     TRISC=0x00;        // PORTC AS OUTPUT
     TRISD=0x00;        // PORTD AS OUTPUT
     }
     
void Analog_Init() {
     ADCON0=0x80;       // Select Fosc/32 AND ANS0
     ADCON1=0x80;       // Select Right Justified and VDD-VSS
     /*Select Channel 0 - AN0*/
     ADCON0.CHS0=0;
     ADCON0.CHS1=0;
     ADCON0.CHS2=0;
     ADCON0.ADON=1;     // Enable ADC Module
     }


void Read_ADC() {
     ADCON0.GO=1;      // start of conversion
     while(ADCON0.GO); // waiting for Conversion's Complete
     delay_us(100);
     //Read lower register
     PORTC=ADRESL;
     //Read higher register
     PORTD=ADRESH;
     }

void main() {
     PORT_Init();
     OSCCON|=0x70;     // Select Internal 8MHz OSC
     Analog_Init();
     while(1)   Read_ADC();
}