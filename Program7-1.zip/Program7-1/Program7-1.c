/*
PIC16F887 Timer0 in counter mode example
*/
void SSD();

void main() {
     PORTA=0x00;                // CLEAR PORTA
     PORTB=0x00;                // CLEAR PORTB
     TRISA.TRISA4=1;            // RA4 IS INPUT FOR T0CKI
     TRISB=0x00;                // PORTB IS OUTPUT
     OSCCON=0x70;               // SELECT 8MHz Internal Oscillator
     OPTION_REG.T0CS=1;        // SELECT COUNTER MODE
     OPTION_REG.T0SE=1;        // SELECT NEGATIVE TRANSITION
     OPTION_REG.PSA=0;         // PRESCALER ASSIGNED TMR0
     OPTION_REG&=0xF8;         // SELCT 1:2 Prescaler
     TMR0=0;
     while(1)
     SSD();
}

void SSD()
{    char LED[16]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,
     0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
     PORTB=LED[TMR0];
     if(TMR0==16)    TMR0=0;    // CLEAR TIMER0
}