#define Ticks_Per_Second 30
#define RATE 5

char LED[10]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
char interrupt_count;
char s1,s10;

void interrupt() {
     if(INTCON.T0IF) interrupt_count++;
     if(interrupt_count==Ticks_Per_Second)
     { s1++; 
       interrupt_count=0;
       if(s1==10) {s10++; s1=0; }
       if(s10==6)  s10=0;
     }
     INTCON.T0IF=0;
     }
     
void PORT_SETUP() {
     PORTC=0x00;  // Clear PORTC
     PORTD=0x00;  // Clear PORTD
     TRISD=0x00;  // PORTD AS OUTPUT
     TRISC=0x00;  // PORTC AS OUTPUT
     }

void timer_setup() {
     OPTION_REG.T0CS=0;    // SELECT INTERNAL SOURCE
     OPTION_REG.PSA=0;     // PRESCALER ASSIGNED TO TMR0
     OPTION_REG|=0x07;     // SELECT 1:256 PRESCALER
     }

void interrupt_setup() {
     INTCON.GIE=1;     // Enable Global Interrut
     INTCON.T0IE=1;    // ENABLE TIMER0 INTERRUPT
     INTCON.T0IF=0;    // CLEAR FLAG
     }

void SSD(){
     PORTC=LED[s10];
     PORTD=0x01;
     delay_ms(RATE);
     PORTD=0x00;
     
     PORTC=LED[s1];
     PORTD=0x02;
     delay_ms(RATE);
     PORTD=0x00;
}

void main() {
     s1=s10=0;
     interrupt_count=0;
     OSCCON|=0x70;
     PORT_SETUP();
     timer_SETUP();
     interrupt_setup();
     while(1)  SSD();
}