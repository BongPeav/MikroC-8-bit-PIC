
#define Servo PORTD.RD0
#define Max_Degree 2000
unsigned ADC_Value;
unsigned Servo_Value;

void main() {
     int i,j;
     PORTD=0x00;
     PORTA=0x00;
     TRISA=0x01;
     ANSEL=0x01;
     TRISD=0x00;
     OSCCON=0x70;
     ADC_Init();
     while(1) {
     ADC_Value=ADC_Get_Sample(0);
     Servo_Value=ADC_Value/4;
       Servo=1;
     for(i=0;i<Servo_Value;i++)  {

         delay_us(1);
         }
         Servo=0;
     for(j=0;j<20000-Servo_Value;j++) {

         delay_us(1);
         }
         delay_ms(5);
         }
     }