
#define STEP_SIZE 0.0048
#define ONE_SECOND 30
#define RATE 10
#define DIGIT1 PORTA.RA6
#define DIGIT2 PORTA.RA7

unsigned ADC_Value;
float  Voltage;
char int_count,volt_count;
char LED[10]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
bit  ADC_RUN;

void interrupt() {
     if(INTCON.T0IF) {
        int_count++;
        if(int_count==ONE_SECOND)
        { int_count=0; ADC_RUN=1; }
        }
     INTCON.T0IF=0;
}

void PORT_SETUP() {
     PORTA=0x00;
     PORTB=0x00;
     TRISA=0x01;   // RA0 IS ANALOG IN PUT
     TRISB=0x00;   // PORTB is OUTPUT
     ANSEL=0x01;   // SELECT AN0
     ANSELH=0x00;   // OTHERS ARE DIGITAL IO
     OSCCON|=0x07;  // SELECT 8MHz INT RC
     }

void Timer0_Setup(){
     OPTION_REG.T0CS=0; // SELECT FOSC/4
     OPTION_REG.PSA=0;  // SELECT TIMER0 PRESCALER
     OPTION_REG|=0x07;  // SELECT 1:256 PRESCALER
     }

void interrupt_setup() {
     INTCON.GIE=1;
     INTCON.T0IE=1;
     INTCON.T0IF=0;
     }

void Read_Voltage () {
     if(ADC_RUN=1) {
        ADC_Value=ADC_Get_Sample(0);   // READ AN0
        delay_ms(10);
        Voltage=ADC_Value*STEP_SIZE;  // Convert to Decimal
      }
       ADC_RUN=0;
}

void SSD() {
     volt_count=Voltage*10;  // convert Voltage to integer
     
     PORTB=LED[Volt_count/10]|0x80;
     DIGIT1=1;
     delay_ms(RATE);
     PORTA=0x00;
     
     PORTB=LED[Volt_count%10];
     DIGIT2=1;
     delay_ms(RATE);
     PORTA=0x00;
}

void main() {
     ADC_Value=0;
     int_count=0;
     ADC_RUN=0;
     PORT_SETUP();
     ADC_Init();
     Timer0_Setup();
     Interrupt_Setup();
     while(1) {
     Read_Voltage();
     SSD();
     }
}